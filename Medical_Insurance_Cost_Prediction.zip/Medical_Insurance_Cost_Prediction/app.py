from flask import Flask, request, jsonify, render_template, redirect, flash, send_file, Response
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib as mpl
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
import plotly.express as px
#Thresholds
import warnings
warnings.filterwarnings("ignore") 

mpl.rcParams["figure.figsize"] = [7, 7]
mpl.rcParams["figure.autolayout"] = True

app = Flask(__name__)

path = "insurance.csv"
insurance = pd.read_csv(path)
df = insurance.copy()

def makeplots():
      i=0
      sns.set()
      plt.figure(figsize=(8,8))
      sns.distplot(insurance['age'],kde=True)
      plt.title('Age distribution',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(8,8))
      sns.distplot(insurance['bmi'],kde=True)
      plt.title('BMI distribution',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(6,6))
      sns.countplot(x='sex',data=insurance)
      plt.title('Sex',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(6,6))
      sns.countplot(x='children',data=insurance)
      plt.title('Children',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(6,6))
      sns.countplot(x='smoker',data=insurance)
      plt.title('Smoker',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(6,6))
      sns.countplot(x='region',data=insurance)
      plt.title('Region',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(8,8))
      sns.distplot(insurance['charges'],kde=True)
      plt.title('Charges distribution',fontsize=18)
      i= i+1
      plt.savefig(f'static/images/try{i}.png')

      plt.figure(figsize=(12,12))
      fig = px.scatter_3d(insurance, x='age', y='bmi', z='charges', color='sex',
                          opacity=0.7, width=800, height=800)
      i=i+1
      fig.write_image(f'static/images/try{i}.png')
      
      

# encoding sex column
df.replace({'sex':{'male':0,'female':1}},inplace=True)
# encoding smoker column
df.replace({'smoker':{'yes':0,'no':1}},inplace=True)
# encoding region column
df.replace({'region':{'southeast':0,'southwest':1,'northeast':2,'northwest':3}},inplace=True)
X = df.drop(columns='charges',axis=1)
Y = df['charges']
X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=2)
reg = LinearRegression()
reg.fit(X_train,Y_train)
train_pred = reg.predict(X_train)
r2_train = metrics.r2_score(Y_train, train_pred)
test_pred = reg.predict(X_test)
r2_test = metrics.r2_score(Y_test, test_pred)
plt.scatter(Y_test, test_pred)
sns.regplot(x=Y_test, y=test_pred)
plt.xlabel('Actual Charges')
plt.ylabel('Predicted Charges')
plt.title('Predicted vs Actual Charges')
plt.savefig('static/images/regplot.png')
print("r2 train : ",r2_train,"r2 test : ",r2_test)
print("mean ab error:",metrics.mean_absolute_error(Y_test, test_pred))


@app.route('/')

@app.route('/index')
def index():
      return render_template('index.html')

@app.route('/prediction')
def prediction():
      return render_template('prediction.html')

@app.route('/login')
def login():
      return render_template('login.html')

@app.route('/analysis')
def analysis():
      return render_template('analysis.html', datadisc = [(df.describe()).to_html(classes="rep_tab")])


@app.route('/predict',methods=['POST'])
def predict():
      feature = [float(x) for x in request.form.values()]
      out = reg.predict(np.array([feature]))
      print("x = ",out[0])
      return render_template('prediction.html', x = round(out[0]))



if __name__ == '__main__':


      makeplots()

      app.run(debug=True)
